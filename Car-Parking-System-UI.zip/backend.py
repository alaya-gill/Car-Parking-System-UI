from flask import Flask, render_template, url_for, request, session, redirect,flash
from flask_pymongo import PyMongo
import bcrypt

app = Flask(__name__)

app.config['MONGO_DBNAME'] = 'log'
app.config['MONGO_URI'] = 'mongodb://localhost:27017/log'

mongo = PyMongo(app)

@app.route('/')
def index():
    '''if 'username' in session:
        return 'You are logged in as ' + session['username']'''

    return render_template('signup.html')

@app.route('/login', methods=['POST','GET'])
def login():

    
    if request.method == 'POST':
        users = mongo.db.users
        login_user = users.find_one({'name' : request.form['u']})
        if login_user and bcrypt.checkpw( request.form['p'].encode(),login_user['password'] ):
            #session['username'] = request.form['username']
            return redirect("/table")
        else:
            flash("Username or Password doesn't exist!","warning")
        
    return render_template('index.html')

@app.route('/register', methods=['POST','GET'])
def register():
    print(request.method)
    if request.method == 'POST':
        users = mongo.db.users
        print(request.form['u'])
        existing_user = users.find_one({'name' : request.form['u']})

        if existing_user is None:
            hashpass = bcrypt.hashpw(request.form['p'].encode('utf-8'), bcrypt.gensalt())
            users.insert({'name' : request.form['u'], 'password' : hashpass,'email' : request.form['e']})
            #session['username'] = request.form['username']
            return redirect(url_for('table'))

        flash("That username already exists!","warning")
    return render_template('signup.html')

@app.route('/table', methods=['GET'])
def table():
    data = mongo.db.data
    d=list(data.find())
    
    return render_template('table.html',data=d)


@app.route('/remove',methods=['POST','GET'])
def remove():
    data = mongo.db.data
    print("f")
    if request.method == 'POST':
        dp = request.get_json()
        print("data",dp)
        history = mongo.db.history
        history.find_one_and_update(
    {"id" : int(dp[0])},
    {"$set":
        {"bill": str(dp[(len(dp)-1)])+"$"}
    },upsert=True
)
        data.delete_one({'id':int(dp[0])})
    return render_template('index.html')

@app.route('/history', methods=['GET'])
def history():
    data = mongo.db.history
    d=list(data.find())
    return render_template('history.html',data=d)

@app.route('/addCar', methods=['POST','GET'])
def addCar():
    if request.method == 'POST':
        history = mongo.db.history
        data = mongo.db.data
        l=-1
        print("history",len(list(history.find())))
        if len(list(history.find()))>0:
            last_user = list(history.find().sort("id", -1).limit(1))
            l= last_user[0]["id"]+1
            
        else:
            l= 0
        existing_car = data.find_one({'number' : request.form['carNumber']})
        if existing_car is None:
            history.insert_one({'id':l,'name':request.form['carName'],'number':request.form['carNumber'],'date':request.form['carDate'],'time':request.form['carTime'],'bill':"0$"})
            data.insert_one({'id':l,'name':request.form['carName'],'number':request.form['carNumber'],'date':request.form['carDate'],'time':request.form['carTime']})
        else:
            flash("Car Number Already Exists","warning")
    return render_template('addCar.html')

@app.route('/search', methods=['POST','GET'])
def search():
    if request.method == 'POST':
        history = mongo.db.history
        search=history.find({'number':request.form['num']})
        if search.count()>0:
            print("if",search)
            return render_template('searchdone.html',data=search)
        else:
            print("else",search)
            flash("Car doesn't exist","warning")
    return render_template('search.html')

@app.route('/logout')
def logout():
    return render_template('signup.html')

if __name__ == '__main__':
    app.secret_key = 'mysecret'
    app.run(debug=True)