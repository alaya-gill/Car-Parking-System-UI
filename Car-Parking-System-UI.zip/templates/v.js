var dating=d1[3].split('-')
var timing=d1[4].split(':')
dating[1]=(parseInt(dating[1]))
dating[2]=(parseInt(dating[2]))
timing[0]=(parseInt(timing[0]))
timing[1]=(parseInt(timing[1]))
alert(dateTime)
if ( (dating[1] <= (parseInt(today.getMonth()+1) )) && (dating[2] <= (parseInt(today.getDate()) )) )
{
    if (((parseInt(timing[0])) <=  (parseInt(today.getHours()))) && ((parseInt(timing[1])) < (parseInt(today.getMinutes()))))
    {

    alert("BILL")
    }


}

var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal

modal.style.display = "block";


// When the user clicks on <span> (x), close the modal
span.onclick = function() {
modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
$.ajax({
    url: "/remove",
    type: "POST",
    contentType: "application/json;charset=UTF-8",
    dataType: "json",
    data: JSON.stringify({'d':d}),
    success: function(response) {
        console.log(response);
    },
    });
}